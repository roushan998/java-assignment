Private App
==============================

Framework - AngularJS with a backend ruby connect
