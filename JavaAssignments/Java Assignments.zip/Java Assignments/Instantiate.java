import java.io.*;
//import java.util.*;
class Template{
   int id=1;
   String name="Souvik";
}
class Instantiate{
	public static void main(String args[]){
	Template t1=new Template();
	System.out.println(t1.id+", "+t1.name);
	}
}
	