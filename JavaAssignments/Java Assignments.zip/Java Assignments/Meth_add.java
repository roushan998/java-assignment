import java.io.*;
class Meth_add{
	public static void main(String args[]){
	int v1=5;
	int v2=7;
	v1=v1+v2;
	System.out.println("5+7="+v1);
	}
}